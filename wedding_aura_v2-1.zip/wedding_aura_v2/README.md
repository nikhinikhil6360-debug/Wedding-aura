# Wedding Aura v2 — custom full-stack starter

A Next.js starter for a digital wedding invitation business targeting India.

## Included
- Responsive Wedding Aura storefront and template gallery
- Invitation builder with live preview and package selection
- Razorpay order creation endpoint
- Server-side Razorpay signature verification
- Unique public invitation page after successful verification
- Guest RSVP form and database persistence
- Supabase schema and environment variable template

## Requirements
- Node.js 20+
- Supabase project
- Razorpay account and API keys (start with TEST keys)
- A deployment host such as Vercel

## Local setup
1. Install Node.js 20 or newer.
2. Extract the ZIP and open the project folder in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env.local`.
5. Add your Supabase URL, anon key, secret key and Razorpay TEST keys.
6. In Supabase SQL Editor, run `supabase/schema.sql`.
7. Run `npm run dev` and open http://localhost:3000.

## Important configuration notes
- `SUPABASE_SECRET_KEY` is a secret. It must never use a `NEXT_PUBLIC_` prefix.
- Use Razorpay TEST mode until end-to-end testing is complete.
- The payment verification endpoint validates the Razorpay signature on the server. For a robust production deployment, also verify payment status through Razorpay's API and implement signed webhooks with idempotency before marking orders paid.
- Add rate limiting, CAPTCHA/abuse protection, customer authentication and ownership checks before offering editing dashboards.
- Add secure photo upload to a private Supabase Storage bucket with file type/size validation and signed URLs.
- The current starter stores invitation details and RSVPs but does not yet implement customer accounts, admin tools, custom domain management, refund handling, webhook reconciliation, email notifications or media uploads.
- Review privacy policy, terms, refund/cancellation policy, data retention and consent requirements with a qualified professional before launch.
- Do not accept live payments until test transactions, webhook handling, database backups, security review and refund flows have been completed.

## Production hardening checklist
- [ ] Razorpay webhook endpoint with signature verification and idempotency
- [ ] Verify payment capture/status with Razorpay API before publishing
- [ ] Authenticated customer dashboard and invitation ownership
- [ ] Admin dashboard with role-based access
- [ ] Secure media upload and storage lifecycle
- [ ] Rate limiting on checkout and RSVP endpoints
- [ ] Input validation and spam protection
- [ ] Privacy, terms, refund and contact pages
- [ ] Monitoring, backups and error alerts
