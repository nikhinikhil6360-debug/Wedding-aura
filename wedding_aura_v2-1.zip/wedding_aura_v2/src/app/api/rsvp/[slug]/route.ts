import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase/server";
export async function POST(req:Request,{params}:{params:{slug:string}}){
 try{
  const form=await req.formData();const guest_name=String(form.get("guest_name")||"").trim();const attendance=String(form.get("attendance")||"");const guest_count=Number(form.get("guest_count")||1);
  if(!guest_name||guest_name.length>100||!["yes","no"].includes(attendance)||!Number.isInteger(guest_count)||guest_count<1||guest_count>20)return NextResponse.json({error:"Invalid RSVP details."},{status:400});
  const db=supabaseAdmin();const {data:inv}=await db.from("invitations").select("id").eq("slug",params.slug).eq("is_published",true).single();if(!inv)return NextResponse.json({error:"Invitation not found."},{status:404});
  const {error}=await db.from("rsvps").insert({invitation_id:inv.id,guest_name,attendance,guest_count});if(error)throw error;
  return new NextResponse(`<html><body style="font-family:Arial;text-align:center;padding:60px"><h1>Thank you!</h1><p>Your RSVP has been received.</p><a href="/i/${params.slug}">Return to invitation</a></body></html>`,{headers:{"content-type":"text/html; charset=utf-8"}});
 }catch(e){console.error("rsvp:",e);return NextResponse.json({error:"Could not save RSVP."},{status:500});}
}