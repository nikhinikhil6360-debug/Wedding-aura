import { NextResponse } from "next/server";
import crypto from "crypto";
import { supabaseAdmin } from "@/lib/supabase/server";
import { razorpayClient } from "@/lib/razorpay";
const safeEqual=(a:string,b:string)=>{const aa=Buffer.from(a),bb=Buffer.from(b);return aa.length===bb.length&&crypto.timingSafeEqual(aa,bb)};
export async function POST(req:Request){
 try{
  const body=await req.json();const {razorpay_order_id,razorpay_payment_id,razorpay_signature,orderId}=body;
  if(!razorpay_order_id||!razorpay_payment_id||!razorpay_signature||orderId!==razorpay_order_id)return NextResponse.json({error:"Invalid payment response."},{status:400});
  const secret=process.env.RAZORPAY_KEY_SECRET;if(!secret)throw new Error("Razorpay secret missing.");
  const expected=crypto.createHmac("sha256",secret).update(`${razorpay_order_id}|${razorpay_payment_id}`).digest("hex");
  if(!safeEqual(expected,razorpay_signature))return NextResponse.json({error:"Payment signature could not be verified."},{status:400});
  const db=supabaseAdmin();
  const {data:order,error}=await db.from("orders").select("id,draft,status,razorpay_order_id,invitation_slug").eq("razorpay_order_id",razorpay_order_id).single();
  if(error||!order)return NextResponse.json({error:"Order not found."},{status:404});
  if(order.status==="paid"&&order.invitation_slug)return NextResponse.json({slug:order.invitation_slug});
  const draft=order.draft as any;
  const slug=`${draft.groom_name}-${draft.bride_name}-${crypto.randomBytes(3).toString("hex")}`.toLowerCase().replace(/[^a-z0-9-]/g,"").replace(/-+/g,"-");
  const {error:inviteError}=await db.from("invitations").insert({order_id:order.id,slug,...draft,is_published:true});
  if(inviteError)throw new Error("Could not publish invitation.");
  const {error:updateError}=await db.from("orders").update({status:"paid",razorpay_payment_id,invitation_slug:slug}).eq("id",order.id);
  if(updateError)throw new Error("Could not update order status.");
  return NextResponse.json({slug});
 }catch(e){console.error("verify-payment:",e);return NextResponse.json({error:"Payment verification or invitation publishing failed. Contact support before retrying."},{status:500});}
}