import { NextResponse } from "next/server";
import { z } from "zod";
import { razorpayClient } from "@/lib/razorpay";
import { supabaseAdmin } from "@/lib/supabase/server";
import { plans } from "@/lib/types";
const schema=z.object({
 plan:z.enum(["classic","signature","royal"]),
 draft:z.object({
  template_slug:z.string().min(1).max(80),groom_name:z.string().min(1).max(60),
  bride_name:z.string().min(1).max(60),wedding_date:z.string().date(),
  venue:z.string().min(1).max(120),city:z.string().min(1).max(100),
  message:z.string().max(600),contact_phone:z.string().max(16).optional()
 })
});
export async function POST(req:Request){
 try{
  const parsed=schema.safeParse(await req.json());if(!parsed.success)return NextResponse.json({error:"Please check the invitation details."},{status:400});
  const {plan,draft}=parsed.data;const amount=plans[plan].amount;
  const db=supabaseAdmin();const {data:order,error}=await db.from("orders").insert({plan,amount_paise:amount,status:"created",draft}).select("id").single();
  if(error||!order)throw new Error("Could not create order record.");
  const rp=razorpayClient();const rOrder=await rp.orders.create({amount,currency:"INR",receipt:order.id,notes:{internal_order_id:order.id}});
  const {error:updateError}=await db.from("orders").update({razorpay_order_id:rOrder.id}).eq("id",order.id);
  if(updateError)throw new Error("Could not link payment order.");
  return NextResponse.json({orderId:rOrder.id,amount,currency:"INR",keyId:process.env.NEXT_PUBLIC_RAZORPAY_KEY_ID});
 }catch(e){console.error("create-order:",e);return NextResponse.json({error:"Checkout is not configured yet or the order could not be created."},{status:503});}
}