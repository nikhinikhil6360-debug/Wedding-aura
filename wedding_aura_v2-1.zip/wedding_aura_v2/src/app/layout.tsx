import type { Metadata } from "next";
import "./globals.css";
export const metadata: Metadata = {
  title: "Wedding Aura | Digital Wedding Invitations",
  description: "Beautiful, personalised digital wedding invitations for Indian celebrations."
};
export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}
