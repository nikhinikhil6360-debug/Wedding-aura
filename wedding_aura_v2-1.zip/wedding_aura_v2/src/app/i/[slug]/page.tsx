import { notFound } from "next/navigation";
import { supabaseAdmin } from "@/lib/supabase/server";
export const dynamic="force-dynamic";
export default async function InvitationPage({params}:{params:{slug:string}}){
 let invitation:any=null;
 try{const {data}=await supabaseAdmin().from("invitations").select("*").eq("slug",params.slug).eq("is_published",true).single();invitation=data;}catch{}
 if(!invitation)notFound();
 const date=invitation.wedding_date?new Date(invitation.wedding_date+"T00:00:00").toLocaleDateString("en-IN",{day:"numeric",month:"long",year:"numeric"}):"";
 return <main className="section"><div className="wrap" style={{maxWidth:680,textAlign:"center"}}><div className="eyebrow">A celebration of love</div><div className="preview" style={{marginTop:20}}><article className="paper" style={{maxWidth:430,minHeight:550}}><div className="orn">✦</div><small>TOGETHER WITH THEIR FAMILIES</small><p>{invitation.message}</p><h2>{invitation.groom_name}</h2><div className="orn">&</div><h2>{invitation.bride_name}</h2><p>request the pleasure of your company<br/>as they begin their forever</p><p style={{color:"var(--wine)",letterSpacing:".12em"}}>{date}</p><p>{invitation.venue}<br/>{invitation.city}</p><p style={{fontSize:10}}>With love, Wedding Aura</p></article></div><RSVP slug={params.slug}/></div></main>
}
function RSVP({slug}:{slug:string}){return <form action={`/api/rsvp/${slug}`} method="post" className="panel" style={{textAlign:"left",marginTop:24}}><h2 style={{fontSize:27}}>Kindly RSVP</h2><div className="field"><label>Your name</label><input name="guest_name" required maxLength={100}/></div><div className="field"><label>Will you be joining?</label><select name="attendance" required><option value="">Select response</option><option value="yes">Joyfully accepting</option><option value="no">Regretfully declining</option></select></div><div className="field"><label>Number of guests</label><input name="guest_count" type="number" min="1" max="20" defaultValue="1"/></div><button className="btn" type="submit">Send RSVP</button></form>}
