export type InvitationDraft = {
  template_slug: string;
  groom_name: string;
  bride_name: string;
  wedding_date: string;
  venue: string;
  city: string;
  message: string;
  contact_phone?: string;
  slug?: string;
};

export const plans = {
  classic: { name: "Classic", amount: 49900 },
  signature: { name: "Signature", amount: 99900 },
  royal: { name: "Royal", amount: 149900 }
} as const;
