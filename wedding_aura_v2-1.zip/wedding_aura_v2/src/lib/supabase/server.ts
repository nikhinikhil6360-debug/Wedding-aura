import { createClient } from "@supabase/supabase-js";

export function supabaseAdmin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const serviceKey = process.env.SUPABASE_SECRET_KEY;
  if (!url || !serviceKey) throw new Error("Supabase server environment is not configured.");
  // Server-only client. Never expose the service-role key to browser code.
  return createClient(url, serviceKey, { auth: { persistSession: false } });
}
