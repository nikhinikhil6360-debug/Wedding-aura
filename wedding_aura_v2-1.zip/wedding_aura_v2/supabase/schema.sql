-- Run in Supabase SQL Editor. Keep the service-role key server-side only.
create extension if not exists pgcrypto;

create table if not exists public.orders (
  id uuid primary key default gen_random_uuid(),
  plan text not null check (plan in ('classic','signature','royal')),
  amount_paise integer not null check (amount_paise > 0),
  status text not null default 'created' check (status in ('created','paid','failed','refunded')),
  draft jsonb not null,
  razorpay_order_id text unique,
  razorpay_payment_id text,
  invitation_slug text unique,
  created_at timestamptz not null default now()
);

create table if not exists public.invitations (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null unique references public.orders(id) on delete cascade,
  slug text not null unique,
  template_slug text not null,
  groom_name text not null,
  bride_name text not null,
  wedding_date date not null,
  venue text not null,
  city text not null,
  message text not null default '',
  contact_phone text,
  is_published boolean not null default true,
  created_at timestamptz not null default now()
);

create table if not exists public.rsvps (
  id uuid primary key default gen_random_uuid(),
  invitation_id uuid not null references public.invitations(id) on delete cascade,
  guest_name text not null,
  attendance text not null check (attendance in ('yes','no')),
  guest_count integer not null default 1 check (guest_count between 1 and 20),
  created_at timestamptz not null default now()
);

create index if not exists invitations_slug_idx on public.invitations(slug);
create index if not exists rsvps_invitation_id_idx on public.rsvps(invitation_id);

-- All writes in this starter happen through server routes using the service role.
-- Public visitors should only read published invitation pages through server routes.
alter table public.orders enable row level security;
alter table public.invitations enable row level security;
alter table public.rsvps enable row level security;
-- No public policies are intentionally created. Do not expose service role key.
